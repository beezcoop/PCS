<?php if (isset($content['apps'])) : ?>
<div id="apps-list">
  <?php print drupal_render($content['apps']) ?>
</div>
<?php endif; ?>
