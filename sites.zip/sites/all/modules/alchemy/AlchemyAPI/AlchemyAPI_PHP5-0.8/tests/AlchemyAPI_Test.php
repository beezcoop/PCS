<?php
require_once('../module/AlchemyAPI.php');
require_once('../module/AlchemyAPIParams.php');
require_once('AlchemyAPI_Test_Main.php');


?>
