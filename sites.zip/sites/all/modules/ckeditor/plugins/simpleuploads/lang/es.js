﻿CKEDITOR.plugins.setLang( 'simpleuploads', 'es',
	{
		addFile	: 'Añadir un fichero',
		addImage: 'Añadir una imagen',
		processing: 'Procesando...',
		fileTooBig : 'El fichero es demasiado grande, por favor, escoja uno menor.',
		invalidExtension : 'Este tipo de fichero no está permitido.',
		nonAcceptedExtension: 'El tipo de fichero no es válido, por favor elija uno correcto:\r\n%0'
	}
);
