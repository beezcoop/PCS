﻿/**
 * @license Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.html or http://ckeditor.com/license
 */

CKEDITOR.plugins.setLang( 'uicolor', 'de', {
	title: 'UI Pipette',
	preview: 'Live-Vorschau',
	config: 'Fügen Sie diese Zeichenfolge in die \'config.js\' Datei.',
	predefined: 'Vordefinierte Farbsätze'
});
