<?php

$aliases['dev'] = array(
 'root' => '/srv/drupal',
 'remote-host' => 'ssh.ac',
 'remote-user' => 'site-fd76dd2d55864da1ad1e75ae251fb5fb',
);